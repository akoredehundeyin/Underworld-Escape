from Player import *
import unittest


class TestPlayer(unittest.TestCase):

    def setUp(self):
        self.player = Player()

    def test_playerLife(self):
        self.assertEqual(self.player.life, 3)
        self.player.lose_life()
        self.assertEqual(self.player.life,2) #Player has lost 1 life and now has 2 lives
        self.player.gain_life()
        self.assertEqual(self.player.life,3) #Player has gained 1 life and now has 3 lives
        self.player.gain_life()
        self.assertEqual(self.player.life,3) #Player can only have a maximum of 3 lives per time


if __name__ == '__main__':
    unittest.main()
