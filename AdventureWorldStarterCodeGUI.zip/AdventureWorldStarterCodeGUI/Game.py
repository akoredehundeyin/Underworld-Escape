
from Place import Place
from Item import Item
from Scene import Scene
import time
import Log

"""
    This class is the main class of the "Adventure World" application. 
    'Adventure World' is a very simple, text based adventure game. Users 
    can walk around some scenery. That's all. It should really be extended 
    to make it more interesting!

    To play this game, create an instance of this class and call the "play"
    method.

    This main class creates and initialises all the others: it creates all
    rooms, creates the parser and starts the game. It also evaluates and
    executes the commands that the parser returns.

    This game is adapted from the 'World of Zuul' by Michael Kolling
    and David J. Barnes. The original was written in Java and has been
    simplified and converted to Python by Kingsley Sage.
"""

class Game:

    def __init__(self):
        """
        Initialises the game.
        """
        self.create_places()
        self.scene = Scene()
        self.current_place = self.underworld
        self.places_visited = []

    def create_places(self):
        """
        Sets up all place assets.
        :return: None
        """
        self.purgatory = Place("Purgatory", False)
        self.coven = Place("Witch Coven", True)
        self.werewolf = Place("Werewolf Camp", True)
        self.vampire = Place("Vampire Lair", True)
        self.minotaur = Place("Minotaur Keep", True)
        self.dragon = Place("Dragon End", True)
        self.cerberus = Place("Cerberus Cage", True)
        self.demon = Place("Demon Hold", False)
        self.hades = Place("Hades Throne Room", True)
        self.edge = Place("World's End", False)
        self.trade_room_two = Place("Trade Portal", False)
        self.sphynx = Place("Sphynx Cell", False)
        self.bogeyman = Place("Bogeyman Pit", False)
        self.asgard = Place("Asgard Deceit", False)
        self.troll = Place("Troll Gutters", False)
        self.siren = Place("Siren Lake", False)
        self.freedom = Place("Freedom!!!", False)
        self.underworld = Place("The Underworld", False)
        self.prison = Place("The Prison", False)

        #Now adding exits to the created locations

        self.underworld.set_exit("north", self.purgatory)
        self.purgatory.set_exit("south", self.underworld)
        self.purgatory.set_exit("east", self.coven)
        self.coven.set_exit("east", self.werewolf)
        self.coven.set_exit("west", self.purgatory)
        self.coven.set_exit("south", self.sphynx)
        self.sphynx.set_exit("north", self.coven)
        self.werewolf.set_exit("south", self.bogeyman)
        self.werewolf.set_exit("north", self.vampire)
        self.werewolf.set_exit("east", self.edge)
        self.werewolf.set_exit("west", self.coven)
        self.bogeyman.set_exit("north", self.werewolf)
        self.vampire.set_exit("east", self.minotaur)
        self.vampire.set_exit("south", self.werewolf)
        self.vampire.set_exit("west", self.asgard)
        self.asgard.set_exit("east", self.vampire)
        self.minotaur.set_exit("west", self.vampire)
        self.minotaur.set_exit("south", self.dragon)
        self.dragon.set_exit("north", self.minotaur)
        self.dragon.set_exit("west", self.edge)
        self.dragon.set_exit("south", self.cerberus)
        self.cerberus.set_exit("east", self.trade_room_two)
        self.cerberus.set_exit("north", self.dragon)
        self.cerberus.set_exit("south", self.troll)
        self.troll.set_exit("north", self.cerberus)
        self.trade_room_two.set_exit("north", self.demon)
        self.trade_room_two.set_exit("west", self.cerberus)
        self.demon.set_exit("west", self.prison)
        self.demon.set_exit("east", self.siren)
        self.demon.set_exit("north", self.hades)
        self.demon.set_exit("south", self.trade_room_two)
        self.siren.set_exit("west", self.demon)
        self.hades.set_exit("east", self.freedom)
        self.hades.set_exit("south", self.demon)

        #Now adding items to the created locations

        self.purgatory.add_item(Item("eye", "an all seeing eye"))
        self.coven.add_item(Item("collar", "a charmed collar"))
        self.werewolf.add_item(Item("stake", "a wooden stake"))
        self.vampire.add_item(Item("hammer", "a large brass hammer"))
        self.minotaur.add_item(Item("sword", "a silver sword"))
        self.dragon.add_item(Item("leash", "a three noose leash"))
        self.cerberus.add_item(Item("coin", "a gold coin"))
        self.demon.add_item(Item("secret", "the best kept secret"))
        self.trade_room_two.add_item(Item("ruby", "the soul stone"))
        self.trade_room_two.add_item(Item("emerald", "the time stone"))
        self.trade_room_two.add_item(Item("sapphire", "the power stone"))


    def print_welcome(self):
        """
        Displays a welcome message.
        The Player sees this message when the game starts
        :return:
        """
        msg = f"You have been imprisoned in the UNDERWORLD...\n" \
              f"\n" \
              f"But all hope is not lost...\n" \
              f"\n" \
              f"You may leave if you defeat Hades\n" \
              f"The keeper of the UNDERWORLD\n" \
              f"\n" \
              f"Your quest starts now"
        return msg


    def print_help(self):
        """
        Display some useful help text.
        :return: message
        """
        Log.log_helpcheck()
        msg = f"You have been imprisoned in the UNDERWORLD...\n" \
              f"\n" \
              f"You are currently in the {self.current_place.description}\n" \
              f"Your controls are on both sides of this screen\n" \
              f"Your Health and Pouch content are here ===>>"
        return msg


    def do_go_command(self, second_word):
        """
        Performs the GO command.
        :param second_word: the direction the player wishes to travel in
        :return: None
        """
        next_place = self.current_place.get_exit(second_word)  # sets the next_place as the place in the direction the player wants to move
        if next_place == None:  # if there is no place in this direction
            return f"There is no door!"
        else:
            if next_place.locked == True:  # if the status of the next place is locked
                return "You cannot proceed yet"
            else:
                Log.log_move(second_word)
                self.places_visited.append(self.current_place) #add the current place to the list of places visited
                self.current_place = next_place  # change places, the next place is now the current place of the player
                return self.place_entry(second_word)

    def place_entry(self, second_word):
        msg = f"Going {second_word}"
        if self.current_place not in self.places_visited:
            time.sleep(0.5)
            Log.log_location(self.current_place.description)
            return "\n".join([str(msg), str(self.scene.place_scene(self.current_place.description))])
        else:
            msg2 = f"You've been here before, you need to hurry"
            return "\n".join([str(msg), str(msg2)])

    def print_stats(self):
        """
        Displays player stats
        Current location, lives and pouch content
        :return: text display of player stats
        """
        Log.log_statsCheck()
        return self.scene.player.show_player_stats()

    def do_use_command(self, second_word):
        """
        Performs the USE command.
        :param second_word: the item the player wishes to use
        :return: None
        """

        if second_word in self.scene.player.pouch:
            if self.current_place == self.purgatory:
                return f"You cannot use that here"
            else:
                Log.log_useItem(second_word)
                self.scene.player.pouch.remove(second_word)
                msg = f"Now using {second_word}"
                return "\n".join([str(msg), str(self.scene.item_scene(self.current_place.description))])
        else:
            if len(self.scene.player.pouch) == 0:
                return f"Your pouch is empty"

    def do_pick_command(self, second_word):
        if len(self.current_place.location_items) == 0:
            return f"There is no item to pick here"
        if second_word in self.current_place.location_items:
            Log.log_pickItem(second_word)
            self.scene.player.pouch.append(second_word)
            self.current_place.location_items.remove(second_word)
            msg = f"You have picked up {'an' if second_word.startswith(('a', 'e', 'i', 'o', 'u')) else 'a'} {second_word}\n" \
                  f"Where do you want to go next?"
            next_places = []
            for i in self.current_place.get_exits():
                next_places.append(self.current_place.get_exit(i))
            for self.next_place in next_places:
                self.next_place.locked = False
            return msg

    def do_drop_command(self, second_word):
        """
        Drops an Item in a Room
        :param second_word: The Item a player wishes to drop
        :return: None
        """
        if second_word in self.scene.player.pouch:
            Log.log_dropItem(second_word)
            self.scene.player.pouch.remove(second_word)
            self.current_place.location_items.append(second_word)
            msg = f"You have dropped {'an' if second_word.startswith(('a', 'e', 'i', 'o', 'u')) else 'a'} {second_word}\n" \
                  f"Now pick anything you desire"
            return msg
        else:
            if len(self.scene.player.pouch) == 0:
                msg = f"Your pouch is empty"
                return msg

    def print_quit(self):
        """
        Prints the quit statement
        :return: text description
        """
        msg = \
            f"Your quest ends here\n" \
            f"Thank You for playing"
        return msg