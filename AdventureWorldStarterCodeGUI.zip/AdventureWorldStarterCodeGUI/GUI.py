import tkinter as tk
from App import App


def main():
    root = tk.Tk()
    root.title("Escaping the UNDERWORLD")
    root.geometry("650x420")
    root.resizable(False, False)

    myapp = App(root)

    root.mainloop()


if __name__ == "__main__":
    main()
