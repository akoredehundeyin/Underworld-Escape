import sys
from time import sleep
from Player import Player

class Scene:

    def __init__(self):
        self.player = Player()

    def place_scene(self, place):
        """
        Describes a place entry scene.
        This will display what happened after a player has used an item in a place
        :param place: A place in the game
        :return: text display of what happens after an item has been used
        """
        if place == "Purgatory":
            sleep(0.2)
            msg = f"You're in Purgatory, your quest out of the underworld starts here\n" \
                 f"You do not have so much time, you must proceed with caution\n" \
                 f"\n" \
                 f"You should always pick an item as you go"
            return msg
        elif place == "Witch Coven":
            sleep(0.2)
            msg = f"You're in the coven of witches, they love the smell of your flesh\n" \
                  f"\n" \
                  f"It appears they cannot see\n" \
                  f"Do you want to make a trade for passage?"
            return msg
        elif place == "Werewolf Camp":
            sleep(0.2)
            msg = f"You are now in the Werewolf's cage, it appears agitated\n" \
                  f"\n" \
                  f"You may tame it\n" \
                  f"Look in your pouch, something might be useful for this"
            return msg
        elif place == "Vampire Lair":
            sleep(0.2)
            msg = f"You are now with Dracula, the first Vampire\n" \
                  f"\n" \
                  f"You can defeat him\n" \
                  f"Use the wooden stake in your pouch\n" \
                  f"Be fierce, drive it into his dead heart"
            return msg
        elif place == "Minotaur Keep":
            sleep(0.2)
            msg = f"You have made good progress\n" \
                  f"\n" \
                  f"You're now with a dreadful beast, a Minotaur\n" \
                  f"\n" \
                  f"Hopefully you have picked up the weapon for this battle"
            return msg
        elif place == "Dragon End":
            sleep(0.2)
            msg = f"You're now in the presence of the fiercest dragon\n" \
                  f"A fire breathing beast\n" \
                  f"\n" \
                  f"It's chest is glowing, it looks like a weakness\n" \
                  f"You may wish to explore this weakness with your sword"
            return msg
        elif place == "Cerberus Cage":
            sleep(0.2)
            msg = f"You're now with Cerberus, the guardian of the underworld\n" \
                  f"A three headed beast that sees everything" \
                  f"\n" \
                  f"Would you have come this far for nothing?\n" \
                  f"Is this where your quest ends?"
            return msg
        elif place == "Demon Hold":
            sleep(0.2)
            msg = f"A demon has just crept up behind you\n" \
                  f"\n" \
                  f"He says you don't have to leave the underworld\n" \
                  f"You have come so far\n" \
                  f"You can be king here\n" \
                  f"You would have a place with Hades himself\n" \
                  f"'Go West, if you choose to keep going' says the demon\n" \
                  f"'...or pay a tribute for a secret'"
            return msg
        elif place == "Hades Throne Room":
            sleep(0.2)
            msg = f"You're before Hades, the god of the underworld\n" \
                  f"\n" \
                  f"Your freedom means nothing to him\n" \
                  f"After all, many more like you are trapped here\n" \
                  f"Feeling generous he says, he decides to grant you freedom" \
                  f"But you must answer a riddle...\n" \
                  f"\n" \
                  f"30 cows were in a field and 28 chickens, how many didn't?"
            return msg
        elif place == "Freedom!!!":
            sleep(0.2)
            msg = f"CONGRATULATIONS!!!! You have won your freedom"
            return msg
        elif place == "World's End":
            sleep(0.2)
            msg = f"You have fallen off the edge of the underworld\n" \
                  f"\n" \
                  f"You were not careful enough\n" \
                  f"\n" \
                  f"\n" \
                  f"GAME OVER!!!"
            return msg
            #return "\n".join([msg, self.game_over()])
        elif place == "Asgard Deceit":
            self.player.life -= 1
            sleep(0.2)
            msg = f"HA HA HA. There is no Asgard in the underworld\n" \
                  f"\n" \
                  f"You shouldn't have come here\n" \
                  f"You have lost a life, you now have {self.player.life}{'lives' if self.player.life > 1 else 'life'}\n" \
                  f"Retrace your steps"
            return msg
        elif place == "The Prison":
            sleep(0.2)
            msg = f"You put your trust in a demon???\n" \
                  f"You have been locked back in the underworld\n" \
                  f"This time?....FOREVER!!!\n" \
                  f"\n" \
                  f"GAME OVER!!!"
            return msg
        elif place in ["Sphynx Cell", "Troll Gutters", "Bogeyman Pit", "Siren Lake"]:
            self.player.life -= 1
            sleep(0.2)
            msg = f"You shouldn't have come here\n" \
                  f"This is {'an' if place.startswith(('a', 'e', 'i', 'o', 'u')) else 'a'} {place}\n" \
                  f"\n" \
                  f"You have lost a life, you now have {self.player.life} {'lives' if self.player.life > 1 else 'life'}\n" \
                  f"\n" \
                  f"Retrace your steps"
            return msg
        elif place == "Trade Portal":
            sleep(0.2)
            msg = f"Would you like to trade?\n" \
                  f""
            return "\n".join([str(msg), str(self.portal_transaction())])
        else:
            return

    def portal_transaction(self):

        if len(self.player.pouch) == 1:
            msg = f"You must drop the item in your pouch for another\n" \
                  f"\n" \
                  f"See your pouch: {self.player.pouch}"
            return msg
        elif len(self.player.pouch) == 0:
            msg = f"You have nothing to trade\n" \
                  f"\n" \
                  f"Your pouch is empty"
            return msg

    def item_scene(self, place):
        """
        Describes an item usage scene.
        This will display what happened after a player has used an item in a place
        :return: text display of what happens after an item has been used
        """
        if place == "Witch Coven":
            sleep(0.2)
            msg = f"The witches have accepted the all seeing eye\n" \
                  f"'We see you prisoner', says the witches...\n" \
                  f"\n" \
                  f"'Pick and item and chase your freedom'..."
            return msg
        elif place == "Werewolf Camp":
            sleep(0.2)
            msg = f"You managed to put the charmed collar around the werewolf's neck\n" \
                  f"\n" \
                  f"The raging werewolf is calm now\n" \
                  f"\n" \
                  f"You have managed to keep your head from being ripped off"
            return msg
        elif place == "Vampire Lair":
            sleep(0.2)
            msg = f"Dracula screams aloud as he burns and flakes away\n" \
                  f"\n" \
                  f"You are lucky you acted quickly\n" \
                  f"\n" \
                  f"Pick up the item under his coffin\n" \
                  f"Then move on, your next adversary is waiting..."
            return msg
        elif place == "Minotaur Keep":
            sleep(0.2)
            msg = f"You swung your hammer swiftly with precision\n" \
                  f"\n" \
                  f"The beast has fallen down cold\n" \
                  f"\n" \
                  f"Quickly, you know the routine, pick an item and move on"
            return msg
        elif place == "Dragon End":
            sleep(0.2)
            msg = f"Your sword's strike was true, the dragon shrieks loudly\n" \
                  f"\n" \
                  f"The dragon breathes a last blast of fire upon a chest\n" \
                  f"Quickly, pick up this item and move"
            return msg
        elif place == "Cerberus Cage":
            sleep(0.2)
            msg = f"Your leash holds this three headed monster\n" \
                  f"\n" \
                  f"Your biggest battle has not been won\n" \
                  f"\n" \
                  f"You must move on after you have picked up an item here"
            return msg
        elif place == "Demon Hold":
            sleep(0.2)
            msg = f"You made the right choice\n" \
                  f"\n" \
                  f"The demon lets you in on a secret\n" \
                  f"You would have been imprisoned forever if you had done east\n" \
                  f"You must go north if you want to meet the one keeping you here\n" \
                  f"Are you ready to be free?\n" \
                  f"Almost there, keep moving. Go North"
            return msg
        elif place == "Trade Portal":
            msg = f"You used your coin\n" \
                  f"But you were asked to drop it\n" \
                  f"\n" \
                  f"You cannot get it back\n" \
                  f"You must now pick an item"
            return msg
        elif place == "Hades Throne Room":
            msg = f"The answer is TEN\n" \
                  f"\n" \
                  f"You have answered Hades' Riddle\n" \
                  f"You may now go east to your Freedom!!"
            return msg
        else:  # If the player tries to use an item in any of these rooms, then that item would be lost
            if place == "Sphynx Cell" or "Siren Lake" or "Bogeyman Pit" or "Troll Gutters" or "Asgard Deceit":
                sleep(0.2)
                msg = f"Your {[i for i in self.player.pouch]} is useless here\n" \
                      f"\n" \
                      f"You have now lost it\n" \
                      f"Go back where you came"

    def update_image(self, place):
        if place == "Witch Coven":
            img = "Images/Witches.jpg"
            return img
        elif place == "The Underworld":
            img = "Images/Underworld.jpg"
            return img
        elif place == "Purgatory":
            img = "Images/Purgatory.jpg"
            return img
        elif place == "Werewolf Camp":
            img = "Images/Werewolf.jpg"
            return img
        elif place == "Vampire Lair":
            img = "Images/Vampire.jpg"
            return img
        elif place == "Minotaur Keep":
            img = "Images/Minotaur.jpg"
            return img
        elif place == "Dragon End":
            img = "Images/Dragon.jpg"
            return img
        elif place == "Cerberus Cage":
            img = "Images/Cerberus.jpg"
            return img
        elif place == "Demon Hold":
            img = "Images/Demon.jpg"
            return img
        elif place == "Hades Throne Room":
            img = "Images/Hades.jpg"
            return img
        elif place == "Trade Portal":
            img = "Images/Trade.jpg"
            return img
        elif place == "Bogeyman Pit":
            img = "Images/Bogeyman.jpg"
            return img
        elif place == "Sphynx Cell":
            img = "Images/Sphynx.jpg"
            return img
        elif place == "Siren Lake":
            img = "Images/Siren.jpg"
            return img
        elif place == "World's End":
            img = "Images/Edge.jpg"
            return img
        elif place == "Asgard Deceit":
            img = "Images/Asgard.jpg"
            return img
        elif place == "Troll Gutters":
            img = "Images/Troll.jpg"
            return img
        elif place == "The Prison":
            img = "Images/Prison.jpg"
            return img
        elif place == "Freedom!!!":
            img = "Images/Freedom.jpg"
            return img
        else:
            return



    def game_over(self):
        sleep(5)
        sys.exit()

