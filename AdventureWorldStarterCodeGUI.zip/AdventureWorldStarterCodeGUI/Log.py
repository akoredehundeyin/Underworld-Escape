import logging
import time

logging.basicConfig(filename=f'Log/log_{time.strftime("%Y%m%d-%H%M%S")}.log', level=logging.INFO, format="%(asctime)s:%(levelname)s:%(message)s")

def log_move(direction):
    logging.info(f"Moved {direction}")
def log_location(location):
    logging.info(f"Entered {location}")
def log_pickItem(item):
    logging.info(f"Picked {item}")
def log_useItem(item):
    logging.info(f"Used {item}")
def log_dropItem(item):
    logging.info(item)
def log_statsCheck():
    logging.info(f"Checked player statistics")
def log_helpcheck():
    logging.info(f"Asked for help")
