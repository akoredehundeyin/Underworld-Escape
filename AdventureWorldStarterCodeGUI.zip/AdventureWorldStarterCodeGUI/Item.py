"""
Creates an item with attributes name and description
"""

class Item:

    def __init__(self, name: str, description: str):
        """
        Constructor Method
        :param name: This is the Item object name
        """
        self.name = name
        self.description = description