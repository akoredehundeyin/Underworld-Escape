
class Player:

    def __init__(self):

        """
        This is the player attributes
        """
        self.life = 3
        self.pouch = []

    def lose_life(self):
        """
        Reduces a player's life by 1
        :return: None
        """
        self.life -= 1

    def gain_life(self):
        """
       Increases a player's life by 1
        :return: None
        """
        if self.life < 3:
            self.life += 1
        else:
            self.life = 3 #A player can only have a maximum of 3 Lives

    def check_life(self):
        """
        This will check the player's lives
        :return: text description
        """

        if self.life > 0:
            return
        else:
            return f"GAME OVER, YOU ARE BACK IN THE UNDERWORLD!!!!"

    def show_player_stats(self):
        """
        Displays player name, life and pouch content
        :return: text description
        """
        return f"You now have {self.life} {'lives' if self.life > 1 else 'life'}\n" \
               f"This is what you have in your Pouch: {self.pouch}"

    def check_pouch(self):
        """
        This will check what is in the player's pouch and return the first/only item
        :return: item in player pouch
        """
        try:
            return self.pouch[0]
        except IndexError:
            return None