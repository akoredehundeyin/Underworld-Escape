import tkinter as tk
from PIL import ImageTk, Image
from Game import Game

class App():

    def __init__(self, root):

        self.game = Game()

        #Setting up Grid layout



        self.frame1 = tk.Frame(root, width=650, height=40, bg="light grey",borderwidth=2)
        self.frame1.pack_propagate(0)
        self.frame1.pack()
        self.frame2 = tk.Frame(root, width=650, height=230, bg="grey", borderwidth=2)
        self.frame2.pack_propagate(0)
        self.frame2.pack()
        self.frame3 = tk.Frame(root, width=120, height=150, bg="white")
        self.frame3.pack_propagate(0)
        self.frame3.pack(side="left", fill="y")
        self.frame4 = tk.Frame(root, width=410, height=150, bg="white", border=True)
        self.frame4.pack_propagate(0)
        self.frame4.pack(side="left", expand=True, fill="both")
        self.frame5 = tk.Frame(root, width=120, height=150, bg="white")
        self.frame5.pack_propagate(0)
        self.frame5.pack(side="left", expand=True, fill="both")

        self.img = ImageTk.PhotoImage((Image.open("Images/Underworld.jpg").resize((650,230), Image.ANTIALIAS)))
        self.picture = tk.Label(self.frame2, image=self.img)
        self.picture.pack(expand=True, fill="both")

        self.text_area1 = tk.Label(self.frame1, bg="white", fg="black", text="")
        self.text_area1.pack(expand=True, fill="both")

        self.text_area2 = tk.Label(self.frame4, bg="white", fg="black", text="")
        self.text_area2.pack(expand=True, fill="both")

        self.blank = tk.Label(self.frame5, width=13, bg="white", borderwidth=0)
        self.blank.grid(row=3, columnspan=3)

        self.text_area3 = tk.Label(self.frame5, width=13, bg="white", borderwidth=0, text="")
        self.text_area3.grid(row=4, columnspan=3)

        self.build_GUI()

    def build_GUI(self):

        self.text_area3.configure(text=f"\U0001F49A: {self.game.scene.player.life} \U0001F392: {self.game.scene.player.pouch}")
        self.text_area2.configure(text=self.game.print_welcome())
        self.text_area1.configure(text=self.game.current_place.get_long_description())


        self.Nbutton = tk.Button(self.frame5, text="N", bg="dark grey", borderwidth=0, command=lambda: self.process_command("Go north")).grid(row=0, column=1, pady=0, padx=0, sticky="nsew")
        self.Ebutton = tk.Button(self.frame5, text="E", bg="grey", borderwidth=0, command=lambda: self.process_command("Go east")).grid(row=1, column=2, pady=0, padx=0, sticky="nsew")
        self.Wbutton = tk.Button(self.frame5, text="W", bg="grey", borderwidth=0, command=lambda: self.process_command("Go west")).grid(row=1, column=0, sticky="nsew")
        self.Sbutton = tk.Button(self.frame5, text="S", bg="grey", borderwidth=0, command=lambda: self.process_command("Go south")).grid(row=2, column=1, pady=0, padx=0, sticky="nsew")
        self.Quit = tk.Button(self.frame5, text="QUIT", bg="black", fg="red", command=lambda: self.process_command("quit")).grid(row=5, columnspan=4, sticky="nsew")


        self.Help = tk.Button(self.frame3, text="Help", bg="white", fg="black", borderwidth=0, border=False, command=lambda: self.process_command("help")).pack(padx=0, pady=0, side="top", expand=True, fill="x")
        self.Stats = tk.Button(self.frame3, text="Stats", bg="white", fg="black", borderwidth=0, command=lambda: self.process_command("stats")).pack(padx=0, pady=0, side="top", expand=True, fill="x")
        self.Use = tk.Button(self.frame3, text="Use Item", bg="white", fg="black", borderwidth=0, command=lambda: self.process_command(f"use {self.game.scene.player.check_pouch()}")).pack(padx=0, pady=0, side="top", expand=True, fill="x")
        self.Pick = tk.Button(self.frame3, text="Pick Item", bg="white", fg="black", borderwidth=0, command=lambda: self.process_command(f"pick {self.game.current_place.check_place_item()}")).pack(padx=0, pady=0, side="top", expand=True, fill="x")
        self.Drop = tk.Button(self.frame3, text="Drop Item", bg="white", fg="black", borderwidth=0, command=lambda: self.process_command(f"drop {self.game.scene.player.check_pouch()}")).pack(padx=0, pady=0, side="top", expand=True, fill="x")


    def get_command(self, input_line):
        """
        Fetches a command from the console.
        :return: a 2-tuple of the form (command_word, second_word)
        """
        word1 = None
        word2 = None
        if input_line != "":
            all_words = input_line.split()
            word1 = all_words[0]
            if len(all_words) > 1:
                word2 = all_words[1]
            else:
                word2 = None
            # Just ignore any other words
        return (word1, word2)

    def process_command(self, command):
        """
        Process a command from the TextUI.
        :param command: a 2-tuple of the form (command_word, second_word)
        :return: True if the game has been quit, False otherwise
        """
        command_word, second_word = self.get_command(command)
        if command_word != None:
            command_word = command_word.upper()
            if command_word == "HELP":
                self.text_area2.configure(text=self.game.print_help())
            elif command_word == "GO":
                self.image_setter(second_word)
                self.text_area2.configure(text=self.game.do_go_command(second_word))
                self.text_area1.configure(text=self.game.current_place.get_long_description())
                self.text_area3.configure(text=f"\U0001F49A: {self.game.scene.player.life} \U0001F392: {self.game.scene.player.pouch}")
            elif command_word == "STATS":
                self.text_area2.configure(text=self.game.print_stats())
            elif command_word == "HELP":
                self.text_area2.configure(text=self.game.print_help())
            elif command_word == "USE":
                self.text_area2.configure(text=self.game.do_use_command(second_word))
                self.text_area3.configure(text=f"\U0001F49A: {self.game.scene.player.life} \U0001F392: {self.game.scene.player.pouch}")
            elif command_word == "PICK":
                self.text_area2.configure(text=self.game.do_pick_command(second_word))
                self.text_area1.configure(text=self.game.current_place.get_long_description())
                self.text_area3.configure(text=f"\U0001F49A: {self.game.scene.player.life} \U0001F392: {self.game.scene.player.pouch}")
            elif command_word == "DROP":
                self.text_area2.configure(text=self.game.do_drop_command(second_word))
                self.text_area1.configure(text=self.game.current_place.get_long_description())
                self.text_area3.configure(text=f"\U0001F49A: {self.game.scene.player.life} \U0001F392: {self.game.scene.player.pouch}")
            elif command_word == "QUIT":
                self.text_area2.configure(text=self.game.print_quit())
                self.frame1.pack_forget()
                self.frame3.pack_forget()
                self.frame5.pack_forget()
                self.img = ImageTk.PhotoImage((Image.open("Images/Thanks.jpg").resize((650, 230), Image.ANTIALIAS)))
                self.picture.configure(image=self.img)
            else:
                # Unknown command...
                self.text_area2.configure(text="Don't know what you mean.")

    def image_setter(self, second_word):
        next_place = self.game.current_place.get_exit(second_word)
        if next_place == None:  # if there is no place in this direction
            return
        else:
            if next_place.locked == True:  # if the status of the next place is locked
                return
            else:
                self.img = self.img = ImageTk.PhotoImage((Image.open(f"{self.game.scene.update_image(next_place.description)}").resize((650, 230), Image.ANTIALIAS)))
                self.picture.configure(image=self.img)






